﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using System.Web.Http;

namespace WebAPI.Controllers
{
    // DB is dbentity
    public class AccountController : ApiController
    {
     
        public IList<AccountList> GetAllAccounts()
        {
            List<AccountList> accountlist = new List<AccountList>();
            // Accounts table in DB contains all accounts related data 
            accountlist = DB.Accounts.ToList();   
            if (accountlist.Count == 0 || accountlist == null)
            {
                return null;
            }
            else
            {
                return accountlist;
            }
        }

        public AccountTransaction GetAccountTransaction(int accountnumber)
        {
            AccountTransaction transaction = new AccountTransaction();
            // AccountTransaction table in DB contains all transaction data wrt account number
            transaction = DB.AccountTransaction.Where(a => a.AccountNumber == accountnumber);
            if(transaction==null)
            {
                return null;
            }
            else
            {
                return transaction;
            }
        }

        public class AccountList
        {
            public int AccountNumber { get; set; }
            public string AccountName { get; set; }
            public string AccountType { get; set; }
            public DateTime BalanceDate { get; set; }
            public string Currency { get; set; }
            public float OpeningBalanceAvailable { get; set; }

        }
        public class AccountTransaction
        {
            public int AccountNumber { get; set; }
            public string AccountName { get; set; }
            public DateTime ValueDate { get; set; }
            public string Currency { get; set; }
            public float DebitAmount { get; set; }
            public float CreditAmount { get; set; }
            public string TransactionType { get; set; }
            public string TransactionNarrative { get; set; }

        }
    }
}
